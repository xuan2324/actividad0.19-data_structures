package com.example;

import javafx.event.ActionEvent;

public class MyController {
    public void crearDocumento(ActionEvent actionEvent) {
    }

    public void leerDocumento(ActionEvent actionEvent) {

    }

    public void actualizarDocumento(ActionEvent actionEvent) {

    }

    public void eliminarDocumento(ActionEvent actionEvent) {

    }

    public void buscarDocumento(ActionEvent actionEvent) {

    }
}
