package com.empresa.datastructure;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import org.bson.Document;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;

public class MyController {

    // Conexión a MongoDB Atlas
    private final MongoClient mongoClient = MongoClients.create("actividad019");

    // Seleccionar la base de datos y la colección
    private final MongoDatabase database = mongoClient.getDatabase("actividad019");
    private final MongoCollection<Document> collection = database.getCollection("actividad019");

    @FXML
    private TextField txtBusqueda;

    @FXML
    private TextArea txtAreaResultados;

    @FXML
    private void buscarDocumento() {
        String terminoBusqueda = txtBusqueda.getText();
        // Realizar búsqueda en MongoDB
        MongoCursor<Document> cursor = collection.find(Filters.eq("campo", terminoBusqueda)).iterator();
        StringBuilder resultados = new StringBuilder();
        while (cursor.hasNext()) {
            Document doc = cursor.next();
            resultados.append(doc.toJson()).append("\n");
        }
        txtAreaResultados.setText("Resultados de la búsqueda para '" + terminoBusqueda + "':\n" + resultados.toString());
    }

    @FXML
    private void crearDocumento() {
        // Implementar lógica para crear un nuevo documento en MongoDB
    }

    @FXML
    private void leerDocumento() {
        // Implementar lógica para leer un documento de MongoDB
    }

    @FXML
    private void actualizarDocumento() {
        // Implementar lógica para actualizar un documento en MongoDB
    }

    @FXML
    private void eliminarDocumento() {
        // Implementar lógica para eliminar un documento de MongoDB
    }
}
